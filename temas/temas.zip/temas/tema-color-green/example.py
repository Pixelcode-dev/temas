# example.py - script de demonstração para Tema Color Green
def main():
    print("Executando demo para: Tema Color Green")

if __name__ == '__main__':
    main()
