# example.py - script de demonstração para Tema Hacker Pro
def main():
    print("Executando demo para: Tema Hacker Pro")

if __name__ == '__main__':
    main()
