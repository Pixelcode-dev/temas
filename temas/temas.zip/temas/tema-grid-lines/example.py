# example.py - script de demonstração para Tema Grid Lines
def main():
    print("Executando demo para: Tema Grid Lines")

if __name__ == '__main__':
    main()
