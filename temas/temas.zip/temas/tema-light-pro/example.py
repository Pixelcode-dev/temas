# example.py - script de demonstração para Tema Light Pro
def main():
    print("Executando demo para: Tema Light Pro")

if __name__ == '__main__':
    main()
