# example.py - script de demonstração para Tema Gradient Energy
def main():
    print("Executando demo para: Tema Gradient Energy")

if __name__ == '__main__':
    main()
