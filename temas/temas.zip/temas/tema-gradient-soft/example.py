# example.py - script de demonstração para Tema Gradient Soft
def main():
    print("Executando demo para: Tema Gradient Soft")

if __name__ == '__main__':
    main()
