# example.py - script de demonstração para Tema Glass Dark
def main():
    print("Executando demo para: Tema Glass Dark")

if __name__ == '__main__':
    main()
