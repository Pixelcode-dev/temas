# example.py - script de demonstração para Tema Synth Neon
def main():
    print("Executando demo para: Tema Synth Neon")

if __name__ == '__main__':
    main()
