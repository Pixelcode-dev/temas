# example.py - script de demonstração para Tema Modern Cards
def main():
    print("Executando demo para: Tema Modern Cards")

if __name__ == '__main__':
    main()
