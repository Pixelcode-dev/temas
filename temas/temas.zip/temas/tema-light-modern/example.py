# example.py - script de demonstração para Tema Light Modern
def main():
    print("Executando demo para: Tema Light Modern")

if __name__ == '__main__':
    main()
