# example.py - script de demonstração para Tema Color Orange
def main():
    print("Executando demo para: Tema Color Orange")

if __name__ == '__main__':
    main()
