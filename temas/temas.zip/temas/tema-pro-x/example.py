# example.py - script de demonstração para Tema Pro X
def main():
    print("Executando demo para: Tema Pro X")

if __name__ == '__main__':
    main()
