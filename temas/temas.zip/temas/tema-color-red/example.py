# example.py - script de demonstração para Tema Color Red
def main():
    print("Executando demo para: Tema Color Red")

if __name__ == '__main__':
    main()
