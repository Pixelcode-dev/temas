# example.py - script de demonstração para Tema Dark Minimal
def main():
    print("Executando demo para: Tema Dark Minimal")

if __name__ == '__main__':
    main()
