# example.py - script de demonstração para Tema Neon Blue
def main():
    print("Executando demo para: Tema Neon Blue")

if __name__ == '__main__':
    main()
