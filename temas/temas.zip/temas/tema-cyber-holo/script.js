// script.js - comportamento de exemplo para Tema Cyber Holo
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Tema Cyber Holo'));
});
