# example.py - script de demonstração para Tema Cyber Holo
def main():
    print("Executando demo para: Tema Cyber Holo")

if __name__ == '__main__':
    main()
