# example.py - script de demonstração para Tema Retro Green
def main():
    print("Executando demo para: Tema Retro Green")

if __name__ == '__main__':
    main()
