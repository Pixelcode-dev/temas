# example.py - script de demonstração para Tema Color Yellow
def main():
    print("Executando demo para: Tema Color Yellow")

if __name__ == '__main__':
    main()
