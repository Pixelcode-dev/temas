# example.py - script de demonstração para Tema Gradient Flow
def main():
    print("Executando demo para: Tema Gradient Flow")

if __name__ == '__main__':
    main()
