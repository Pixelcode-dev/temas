# example.py - script de demonstração para Tema Grid Terminal
def main():
    print("Executando demo para: Tema Grid Terminal")

if __name__ == '__main__':
    main()
