# example.py - script de demonstração para Tema Color Cyan
def main():
    print("Executando demo para: Tema Color Cyan")

if __name__ == '__main__':
    main()
