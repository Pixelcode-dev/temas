# example.py - script de demonstração para Tema Minimal Line
def main():
    print("Executando demo para: Tema Minimal Line")

if __name__ == '__main__':
    main()
