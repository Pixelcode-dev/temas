# example.py - script de demonstração para Tema Zen Dark
def main():
    print("Executando demo para: Tema Zen Dark")

if __name__ == '__main__':
    main()
