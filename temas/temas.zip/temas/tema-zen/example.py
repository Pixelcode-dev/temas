# example.py - script de demonstração para Tema Zen
def main():
    print("Executando demo para: Tema Zen")

if __name__ == '__main__':
    main()
