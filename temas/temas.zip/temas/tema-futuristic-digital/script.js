// script.js - comportamento de exemplo para Tema Futuristic Digital
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Tema Futuristic Digital'));
});
