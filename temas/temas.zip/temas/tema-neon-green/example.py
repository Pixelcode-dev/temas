# example.py - script de demonstração para Tema Neon Green
def main():
    print("Executando demo para: Tema Neon Green")

if __name__ == '__main__':
    main()
