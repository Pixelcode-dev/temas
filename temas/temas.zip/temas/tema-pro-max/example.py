# example.py - script de demonstração para Tema Pro Max
def main():
    print("Executando demo para: Tema Pro Max")

if __name__ == '__main__':
    main()
