# example.py - script de demonstração para Tema Ultimate
def main():
    print("Executando demo para: Tema Ultimate")

if __name__ == '__main__':
    main()
