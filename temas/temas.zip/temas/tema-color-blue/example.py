# example.py - script de demonstração para Tema Color Blue
def main():
    print("Executando demo para: Tema Color Blue")

if __name__ == '__main__':
    main()
