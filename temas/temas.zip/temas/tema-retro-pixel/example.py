# example.py - script de demonstração para Tema Retro Pixel
def main():
    print("Executando demo para: Tema Retro Pixel")

if __name__ == '__main__':
    main()
