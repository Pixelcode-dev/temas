// script.js - comportamento de exemplo para Tema Glass Clear
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Tema Glass Clear'));
});
