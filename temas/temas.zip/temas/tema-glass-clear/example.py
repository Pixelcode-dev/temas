# example.py - script de demonstração para Tema Glass Clear
def main():
    print("Executando demo para: Tema Glass Clear")

if __name__ == '__main__':
    main()
