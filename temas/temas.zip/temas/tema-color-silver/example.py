# example.py - script de demonstração para Tema Color Silver
def main():
    print("Executando demo para: Tema Color Silver")

if __name__ == '__main__':
    main()
