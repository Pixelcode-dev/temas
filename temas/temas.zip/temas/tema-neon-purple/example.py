# example.py - script de demonstração para Tema Neon Purple
def main():
    print("Executando demo para: Tema Neon Purple")

if __name__ == '__main__':
    main()
