# example.py - script de demonstração para Tema Glow Bright
def main():
    print("Executando demo para: Tema Glow Bright")

if __name__ == '__main__':
    main()
