# example.py - script de demonstração para Tema Pro Clean
def main():
    print("Executando demo para: Tema Pro Clean")

if __name__ == '__main__':
    main()
