# example.py - script de demonstração para Tema Zen Light
def main():
    print("Executando demo para: Tema Zen Light")

if __name__ == '__main__':
    main()
