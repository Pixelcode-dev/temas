# example.py - script de demonstração para Tema Tech Orion
def main():
    print("Executando demo para: Tema Tech Orion")

if __name__ == '__main__':
    main()
