# example.py - script de demonstração para Tema Modern Neon
def main():
    print("Executando demo para: Tema Modern Neon")

if __name__ == '__main__':
    main()
