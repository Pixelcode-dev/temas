# example.py - script de demonstração para Tema Synth Dark
def main():
    print("Executando demo para: Tema Synth Dark")

if __name__ == '__main__':
    main()
