# example.py - script de demonstração para Tema Hacker Terminal
def main():
    print("Executando demo para: Tema Hacker Terminal")

if __name__ == '__main__':
    main()
