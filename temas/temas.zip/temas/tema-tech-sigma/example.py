# example.py - script de demonstração para Tema Tech Sigma
def main():
    print("Executando demo para: Tema Tech Sigma")

if __name__ == '__main__':
    main()
