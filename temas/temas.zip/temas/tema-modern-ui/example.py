# example.py - script de demonstração para Tema Modern Ui
def main():
    print("Executando demo para: Tema Modern Ui")

if __name__ == '__main__':
    main()
