# example.py - script de demonstração para Tema Dev Cyber
def main():
    print("Executando demo para: Tema Dev Cyber")

if __name__ == '__main__':
    main()
