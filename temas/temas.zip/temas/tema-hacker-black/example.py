# example.py - script de demonstração para Tema Hacker Black
def main():
    print("Executando demo para: Tema Hacker Black")

if __name__ == '__main__':
    main()
