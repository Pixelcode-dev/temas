# example.py - script de demonstração para Tema Gradient Photon
def main():
    print("Executando demo para: Tema Gradient Photon")

if __name__ == '__main__':
    main()
