# example.py - script de demonstração para Tema Color Teal
def main():
    print("Executando demo para: Tema Color Teal")

if __name__ == '__main__':
    main()
