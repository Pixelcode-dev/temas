# example.py - script de demonstração para Tema Modern Glass
def main():
    print("Executando demo para: Tema Modern Glass")

if __name__ == '__main__':
    main()
