# example.py - script de demonstração para Tema Dev Console
def main():
    print("Executando demo para: Tema Dev Console")

if __name__ == '__main__':
    main()
