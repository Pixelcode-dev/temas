# example.py - script de demonstração para Tema Dev Clean
def main():
    print("Executando demo para: Tema Dev Clean")

if __name__ == '__main__':
    main()
