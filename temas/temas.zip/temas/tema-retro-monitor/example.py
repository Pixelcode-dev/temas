# example.py - script de demonstração para Tema Retro Monitor
def main():
    print("Executando demo para: Tema Retro Monitor")

if __name__ == '__main__':
    main()
