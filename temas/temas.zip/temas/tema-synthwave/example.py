# example.py - script de demonstração para Tema Synthwave
def main():
    print("Executando demo para: Tema Synthwave")

if __name__ == '__main__':
    main()
