# example.py - script de demonstração para Tema Modern Flat
def main():
    print("Executando demo para: Tema Modern Flat")

if __name__ == '__main__':
    main()
