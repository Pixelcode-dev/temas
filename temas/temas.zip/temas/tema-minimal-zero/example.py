# example.py - script de demonstração para Tema Minimal Zero
def main():
    print("Executando demo para: Tema Minimal Zero")

if __name__ == '__main__':
    main()
