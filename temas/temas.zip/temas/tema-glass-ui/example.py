# example.py - script de demonstração para Tema Glass Ui
def main():
    print("Executando demo para: Tema Glass Ui")

if __name__ == '__main__':
    main()
