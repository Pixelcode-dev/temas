# example.py - script de demonstração para Tema Minimal Black
def main():
    print("Executando demo para: Tema Minimal Black")

if __name__ == '__main__':
    main()
