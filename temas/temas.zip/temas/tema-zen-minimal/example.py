# example.py - script de demonstração para Tema Zen Minimal
def main():
    print("Executando demo para: Tema Zen Minimal")

if __name__ == '__main__':
    main()
