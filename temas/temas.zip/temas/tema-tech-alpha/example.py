# example.py - script de demonstração para Tema Tech Alpha
def main():
    print("Executando demo para: Tema Tech Alpha")

if __name__ == '__main__':
    main()
