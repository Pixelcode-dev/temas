# example.py - script de demonstração para Tema Dev Dark
def main():
    print("Executando demo para: Tema Dev Dark")

if __name__ == '__main__':
    main()
