# example.py - script de demonstração para Tema Light Ui
def main():
    print("Executando demo para: Tema Light Ui")

if __name__ == '__main__':
    main()
