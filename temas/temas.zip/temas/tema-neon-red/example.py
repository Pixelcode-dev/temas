# example.py - script de demonstração para Tema Neon Red
def main():
    print("Executando demo para: Tema Neon Red")

if __name__ == '__main__':
    main()
