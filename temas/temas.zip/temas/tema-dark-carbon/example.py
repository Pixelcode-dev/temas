# example.py - script de demonstração para Tema Dark Carbon
def main():
    print("Executando demo para: Tema Dark Carbon")

if __name__ == '__main__':
    main()
