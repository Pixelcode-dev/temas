# example.py - script de demonstração para Tema Dev Cards
def main():
    print("Executando demo para: Tema Dev Cards")

if __name__ == '__main__':
    main()
