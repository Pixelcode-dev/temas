// script.js - comportamento de exemplo para Tema Dev Cards
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Tema Dev Cards'));
});
