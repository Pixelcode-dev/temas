# example.py - script de demonstração para Tema Dev Ui
def main():
    print("Executando demo para: Tema Dev Ui")

if __name__ == '__main__':
    main()
