# example.py - script de demonstração para Tema Minimal Waves
def main():
    print("Executando demo para: Tema Minimal Waves")

if __name__ == '__main__':
    main()
