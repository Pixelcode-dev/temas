# example.py - script de demonstração para Tema Cyber Neon
def main():
    print("Executando demo para: Tema Cyber Neon")

if __name__ == '__main__':
    main()
