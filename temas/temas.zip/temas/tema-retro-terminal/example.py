# example.py - script de demonstração para Tema Retro Terminal
def main():
    print("Executando demo para: Tema Retro Terminal")

if __name__ == '__main__':
    main()
