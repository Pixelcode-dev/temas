# example.py - script de demonstração para Tema Glass Holo
def main():
    print("Executando demo para: Tema Glass Holo")

if __name__ == '__main__':
    main()
