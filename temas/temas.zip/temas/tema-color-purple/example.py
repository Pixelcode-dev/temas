# example.py - script de demonstração para Tema Color Purple
def main():
    print("Executando demo para: Tema Color Purple")

if __name__ == '__main__':
    main()
