# example.py - script de demonstração para Tema Minimal White
def main():
    print("Executando demo para: Tema Minimal White")

if __name__ == '__main__':
    main()
