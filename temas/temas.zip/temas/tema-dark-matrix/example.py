# example.py - script de demonstração para Tema Dark Matrix
def main():
    print("Executando demo para: Tema Dark Matrix")

if __name__ == '__main__':
    main()
