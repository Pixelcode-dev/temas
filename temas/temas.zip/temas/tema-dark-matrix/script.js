// script.js - comportamento de exemplo para Tema Dark Matrix
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Tema Dark Matrix'));
});
