# example.py - script de demonstração para Tema Dark Terminal
def main():
    print("Executando demo para: Tema Dark Terminal")

if __name__ == '__main__':
    main()
