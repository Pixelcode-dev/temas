# example.py - script de demonstração para Tema Pro Ultra
def main():
    print("Executando demo para: Tema Pro Ultra")

if __name__ == '__main__':
    main()
