# example.py - script de demonstração para Tema Tech Beta
def main():
    print("Executando demo para: Tema Tech Beta")

if __name__ == '__main__':
    main()
