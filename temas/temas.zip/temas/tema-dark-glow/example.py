# example.py - script de demonstração para Tema Dark Glow
def main():
    print("Executando demo para: Tema Dark Glow")

if __name__ == '__main__':
    main()
