# example.py - script de demonstração para Tema Modern Frost
def main():
    print("Executando demo para: Tema Modern Frost")

if __name__ == '__main__':
    main()
